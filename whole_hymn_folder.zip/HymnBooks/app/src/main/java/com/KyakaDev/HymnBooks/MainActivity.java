package com.KyakaDev.HymnBooks;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;

import android.content.Context;
import android.content.Intent;

import android.net.Uri;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import android.view.ViewGroup;

import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private static final int CURRENT_VERSION_CODE = 3;

    private static final String JSON_URL =
        "https://raw.githubusercontent.com/kyakadev2/update.json/main/update.json";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        webView = new WebView(this);

        webView.setLayoutParams(
            new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);

        settings.setDomStorageEnabled(true);

        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(
            new WebAppInterface(this),
            "Android");

        webView.setWebViewClient(
            new WebViewClient() {

                @Override
                public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request) {

                    Uri uri = request.getUrl();

                    String scheme = uri.getScheme();

                    try {

                        if ("mailto".equals(scheme)) {

                            startActivity(
                                new Intent(
                                    Intent.ACTION_SENDTO,
                                    uri));

                            return true;
                        }

                        if ("tel".equals(scheme)) {

                            startActivity(
                                new Intent(
                                    Intent.ACTION_DIAL,
                                    uri));

                            return true;
                        }

                        if ("http".equals(scheme) ||
                            "https".equals(scheme)) {

                            startActivity(
                                new Intent(
                                    Intent.ACTION_VIEW,
                                    uri));

                            return true;
                        }

                    } catch (Exception e) {

                        Toast.makeText(
                            MainActivity.this,
                            "No app found to open link",
                            Toast.LENGTH_SHORT)
                            .show();
                    }

                    return false;
                }
            });

        webView.setWebChromeClient(
            new WebChromeClient() {

                @Override
                public boolean onJsAlert(
                    WebView view,
                    String url,
                    String message,
                    JsResult result) {

                    Toast.makeText(
                        MainActivity.this,
                        message,
                        Toast.LENGTH_SHORT)
                        .show();

                    result.confirm();

                    return true;
                }
            });

        webView.loadUrl(
            "file:///android_asset/index.html");

        setContentView(webView);

        new CheckUpdateTask().execute();
    }

    public class WebAppInterface {

        Context context;

        WebAppInterface(Context ctx) {

            context = ctx;
        }

        @JavascriptInterface
        public void shareText(String text) {

            Intent intent =
                new Intent(Intent.ACTION_SEND);

            intent.setType("text/plain");

            intent.putExtra(
                Intent.EXTRA_TEXT,
                text);

            context.startActivity(
                Intent.createChooser(
                    intent,
                    "Share via"));
        }
    }

    @Override
    public void onBackPressed() {

        if (webView.canGoBack()) {

            webView.goBack();

        } else {

            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        if (webView != null) {

            webView.destroy();
        }
    }

    private void showUpdateNotification(
        String message,
        String downloadUrl) {

        NotificationManager nm =
            (NotificationManager)
            getSystemService(
                Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            NotificationChannel channel =
                new NotificationChannel(
                    "update_channel",
                    "App Updates",
                    NotificationManager.IMPORTANCE_HIGH);

            nm.createNotificationChannel(channel);
        }

        Intent intent =
            new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(downloadUrl));

        PendingIntent pi;

        // Android 12+ compatibility update
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            pi = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
                | PendingIntent.FLAG_IMMUTABLE);

        } else {

            pi = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        }

        Notification.Builder builder;

        // Android 8+ notification channel support
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            builder =
                new Notification.Builder(
                    this,
                    "update_channel");

        } else {

            builder =
                new Notification.Builder(this);
        }

        Notification notification =
            builder
            .setSmallIcon(
                android.R.drawable
                .stat_sys_download_done)
            .setContentTitle(
                "New version available")
            .setContentText(message)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build();

        nm.notify(1, notification);
    }

    private class CheckUpdateTask
        extends AsyncTask<Void, Void, JSONObject> {

        @Override
        protected JSONObject doInBackground(
            Void... params) {

            try {

                HttpURLConnection conn =
                    (HttpURLConnection)
                    new URL(JSON_URL)
                    .openConnection();

                conn.setConnectTimeout(5000);

                conn.setReadTimeout(5000);

                BufferedReader reader =
                    new BufferedReader(
                        new InputStreamReader(
                            conn.getInputStream()));

                StringBuilder sb =
                    new StringBuilder();

                String line;

                while ((line = reader.readLine())
                    != null) {

                    sb.append(line);
                }

                reader.close();

                return new JSONObject(
                    sb.toString());

            } catch (Exception e) {

                return null;
            }
        }

        @Override
        protected void onPostExecute(
            JSONObject json) {

            if (json == null) {

                return;
            }

            try {

                int version =
                    json.getInt("version");

                if (version >
                    CURRENT_VERSION_CODE) {

                    showUpdateNotification(
                        json.getString("message"),
                        json.getString(
                            "download_url"));
                }

            } catch (Exception ignored) {
            }
        }
    }
}